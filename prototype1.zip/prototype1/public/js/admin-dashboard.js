var add-admin = document.getElementById('show-form');
var form = document.getElementById('form');
  add-admin.addEventListener('click',function() {
     if(form.style.display === 'block'){
       form.style.display = 'none';
     }
     else{
       form.style.display = 'block';
     }
  });
