var initWebRoutes = require("./router/web");
// var homePageController =  require("./controllers/homePageController");
var registerController = require("./controllers/registerController");
var loginController = require("./controllers/loginController");
var auth = require("./validation/authValidation");

const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const _ = require("lodash");
var Cart = require('./models/cart');
const app = express();
var session = require('express-session');
var cookieParser = require('cookie-parser');
var passport = require('passport');
var connectFlash = require('connect-flash');
var path = require('path');
const upload = require('express-fileupload');
var blog = require('./router/blog');
require('dotenv').config();

var back = require('express-back');

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

app.use(upload());


const alertMsg = require('alert');


//************DATABASE*********************************************
var datastatus;
var alert;
var successupload = "You should Post Your Content Here !";
// import mysql package
var mysql = require('mysql');
// connect mysql database
var con = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:"",
    database:"commercialweb"
});

// check whether it is connect or not
con.connect(function(err) {
  if(err) throw err;
    console.log("database connect sucessfully...");

});
//**************************************************************************

app.use(cookieParser());
app.use(session({
  secret: 'mysupersecret',
  resave: false,
  saveUninitialized: false,
  // store: express-mysql,
  // cookie: {secure : true}
  cookie: {maxAge: 1000 * 60 * 60 * 24 }
}));



// initPassportLocalAdmin();



app.use(passport.initialize());
app.use(passport.session());

app.use(back());



// ***********************************************************
// ################  BLOG  ###################################
// **********************************************************

app.use('/blog',blog);


var dis = 0;
var prName = "";
var prImg = "";
var prPrice = 0;
var prId = 0;

//---------login page-------------------------
app.use(bodyParser.json());
app.use(connectFlash());
initWebRoutes(app);
//-------------------------------------------


//==================================================================================================================================================
//**********ADMIN_PANEL*****************************************************************************************************************************
//==================================================================================================================================================

app.get("/dash-admin",function(req,res) {
  req.session.admin = undefined;
  res.render("admin/login/adminlogin.ejs");
});

app.get("/dashboard",function(req,res) {

  if(req.session.admin!=undefined) {
    if(req.session.admin.u === process.env.adminname) {
  var query = "SELECT * FROM adminlogin";
  con.query(query, function (err, result) {
   if (err) throw err;
   console.log(result);
   res.render("admin/dashboard.ejs",{admindata:result});
   });
 }
 }else{
 res.redirect("/dash-admin");
}
});


 app.post("/admin-login",function(req,res) {
   var user_name = req.body.adminname;
   var user_pass = req.body.password;
   // console.log(req.body.adminname,process.env.adminname);
   // ########### database ##### table : adminlogin ################
   if(user_name === process.env.adminname && user_pass === process.env.adminpassword){
     req.session.admin = {u:user_name,p:user_pass};
     console.log(req.session.admin);
    res.redirect("/dashboard");
   }
   else{

     var searchquery = "SELECT *FROM adminlogin WHERE adminname = ? AND password = ?";
     con.query(searchquery,[user_name,user_pass],function(err,response) {
       console.log(response);
       if(response.length === 0){
         res.redirect("/dash-admin");
       }else{
         if(response[0].adminname === user_name && response[0].password === user_pass){
           req.session.admin = {u:response[0].adminname,p:response[0].password};
           res.render("admin/useradmin.ejs");
         }
       }
     });
   }
   // res.send(req.body);

});

app.post("/add-admin",function(req,res) {

  console.log(req.body);
  var email = req.body.email;
  var password = req.body.pass;
  var insertquery = "INSERT INTO adminlogin (adminname , password) VALUES (?, ?)";
  var query = mysql.format(insertquery,[email,password]);

  con.query(query, function (err, result) {
   if (err) throw err;
   console.log("1 record inserted");
   res.redirect("/dashboard");
   });

});

app.get("/deal-day",function(req,res) {

if(req.session.admin!=undefined) {
  var query = "SELECT * FROM product";
  con.query(query,function(err,result) {
    if(err) throw err;
    var query = "SELECT * FROM deal";
    con.query(query,function(err,response) {
      if(err) throw err;

      res.render("admin/dealoftheday.ejs",{productdata:result,livedeal:response});
    });
  });
}
else{
  res.redirect("dash-admin");
}
});

app.post("/setdeal",function(req,res) {
  var deal_prod_name = req.body.dealprod;
  var deal_prod_discount = req.body.discount;
  var insertquery = "INSERT INTO deal (dealname , discount) VALUES (?, ?)";
  var query = mysql.format(insertquery,[deal_prod_name,deal_prod_discount]);

  con.query(query, function (err, result) {
   if (err) throw err;
   console.log("1 record inserted");
   res.redirect("/deal-day");
   });
});
app.post("/dealdelete",function(req,res) {
  var delete_content = req.body.dealdelete;
  var query = "DELETE FROM deal WHERE deal_id =?";
  con.query(query,[delete_content],function (err, result) {
     if(err) throw err;
     // console.log(result);
     // res.send(result);
     res.redirect("/deal-day");
  });
});
app.get("/categoryadd",function(req,res) {
if(req.session.admin!=undefined) {
  // fetch data into category table
   var query = "SELECT * FROM category";
   con.query(query, function (err, result) {
   if (err) throw err;
   // console.log(result);
   // console.log(result.length);
   res.render("admin/addcategory.ejs",{filestatus:successupload,response:result,alert:alert});
   });
 }
 else{
   res.redirect("dash-admin");
 }
});
app.post("/categoryadd",function(req,res){
   // console.log(req.body.catimg);
   // console.log(req.files.catimg);
   // console.log(req.body.desc);
   // res.send("sucessfully");
   var category_name = req.body.catname;
   var category_img_name = req.files.catimg.name;
   var filesize = req.files.catimg.size;
   var filemd5 = req.files.catimg.md5;
   var description = req.body.desc;
   if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send('No files were uploaded.');
  }
  // save into category table on commercialweb database

  var insertquery = "INSERT INTO category (name , image, description) VALUES (?, ?, ?)";
  var query = mysql.format(insertquery,[category_name,category_img_name,description]);

  con.query(query, function (err, result) {
   if (err) throw err;
   console.log("1 record inserted");
   });

  // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
  let sampleFile = req.files.catimg;
  // Use the mv() method to place the file somewhere on your server
  var dirpath = "/public/upload/"+category_img_name;
  sampleFile.mv(path.join(__dirname,dirpath), function(err) {

      if (err)
      return res.status(500).send(err);
      successupload  = "Sucessfully Upload Your Post";
      res.redirect("/categoryadd");
  });

});
app.get("/addproduct",function(req,res) {
if(req.session.admin!=undefined) {
   var length;
   var responselist;
   // fetch data of category table form commercialweb;
    var query = "SELECT * FROM category";
    con.query(query,function(err,responsecategory) {
        if(err) throw err;
        var queryforproduct = "SELECT *FROM product";
        con.query(queryforproduct,function(err,responseproduct) {
          if(err) throw err;
          // console.log(responseproduct);
          res.render("admin/addproduct.ejs",{categorylist:responsecategory,productlist:responseproduct});

        });

    });
  }
  else{
    res.redirect("dash-admin");
  }
});
app.post("/addproduct",function(req,res) {
   // var product_name = req.body
   // console.log(req.body);
   // console.log(req.files.prodimg1);
   // console.log(req.files.prodimg2);
   // console.log(req.files.prodimg3);
  //image uploaded variable display Status of Quantity
  var totalimg ;
  // save into product table on commercialweb database
  var prodname = req.body.prodname;
  var prodprice = req.body.prodprice;
  var prodcategory = req.body.prodcategory;
  var description = req.body.desc;
  var stck = req.body.stock;
  var nameimg1 = "";
  var nameimg2 = "";
  var nameimg3 = "";
  if(!req.files.prodimg1){
    res.send("please insert image 1");
  }
  else{
    // variable to handle image : 1
    var nameimg1 = req.files.prodimg1.name;
    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    let sampleFile = req.files.prodimg1;
    // Use the mv() method to place the file somewhere on your server
    var dirpath = "/public/upload/product/"+nameimg1;
    sampleFile.mv(path.join(__dirname,dirpath), function(err) {

        if (err)
        return res.status(500).send(err);
        // successupload  = "Sucessfully Upload Your Post";
        totalimg = 1;
    });
  }
  if(req.files.prodimg2){
    // variable to handle image : 2
    var nameimg2 = req.files.prodimg2.name;
    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    let sampleFile = req.files.prodimg2;
    // Use the mv() method to place the file somewhere on your server
    var dirpath = "/public/upload/product/"+nameimg2;
    sampleFile.mv(path.join(__dirname,dirpath), function(err) {

        if (err)
        return res.status(500).send(err);
        // successupload  = "Sucessfully Upload Your Post";
        totalimg ++;
    });
  }
  if(req.files.prodimg3){
    // variable to handle image : 3
    var nameimg3 = req.files.prodimg3.name;
    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    let sampleFile = req.files.prodimg3;
    // Use the mv() method to place the file somewhere on your server
    var dirpath = "/public/upload/product/"+nameimg3;
    sampleFile.mv(path.join(__dirname,dirpath), function(err) {

        if (err)
        return res.status(500).send(err);
        // successupload  = "Sucessfully Upload Your Post";
        totalimg ++;
    });
  }

  // insert data into product table
  var insertquery = "INSERT INTO product (name, price, category, description, image1, image2, image3, stock) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
  var query = mysql.format(insertquery,[prodname, prodprice, prodcategory, description, nameimg1, nameimg2, nameimg3, stck]);

  con.query(query, function (err, result) {
   if (err) throw err;
   console.log("1 record inserted into product table");
   });

   // res.send(totalimg);
   res.redirect("/addproduct");
});

app.post("/delete",function(req,res) {
  // console.log(req.body);
  var delete_content = req.body.delete;
  var query = "DELETE FROM product WHERE product_id =?";
  con.query(query,[delete_content],function (err, result) {
     if(err) throw err;
     // console.log(result);
     // res.send(result);
     res.redirect("/addproduct");
  });
});
app.post("/delete-cat",function(req,res) {
  var delete_content = req.body.delete;
  console.log("DEL  "+delete_content);
  var query = "SELECT * FROM product WHERE category = ?";
  con.query(query,[delete_content],function(err,result) {
     if(err) throw err;
     if(result.length!=0){
       alert = "yes";
       successupload = "Cannot Delete Category";
       res.redirect("/categoryadd");
     }
     else{
       var query = "DELETE FROM category WHERE name =?";
      con.query(query,[delete_content],function (err, result) {
         if(err) throw err;
         // console.log(result);
         // res.send(result);
         res.redirect("/categoryadd");
      });
     }
  });
  // var query = "DELETE FROM category WHERE name =?";
  // con.query(query,[delete_content],function (err, result) {
  //    if(err) throw err;
  //    console.log(result);
  //    // res.send(result);
  //    res.redirect("/categoryadd");
  // });
});
app.get("/delivery",function(req,res) {
if(req.session.admin!=undefined) {
   var query = "SELECT * FROM area";
   con.query(query, function (err, result) {
    if (err) throw err;
    console.log(result);
    // res.redirect("/delivery");
    res.render("admin/deliveryarea.ejs",{data:result});
    });
  }
  else{
    res.redirect("dash-admin");
  }

});
app.post("/delivery",function(req,res) {
   console.log(req.body);
   // res.send(req.body);
   var name = req.body.areaname;
   var pin = req.body.pincode;
   var insertquery = "INSERT INTO area (areaname, pincode ) VALUES (?, ?)";
   var query = mysql.format(insertquery,[name,pin]);

   con.query(query, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted into area table");
    res.redirect("/delivery");
    });



});
app.post("/deletearea",function(req,res) {

  var delete_content = req.body.delete;
  var query = "DELETE FROM area WHERE area_id =?";
  con.query(query,[delete_content],function (err, result) {
     if(err) throw err;
     console.log(result);
     // res.send(result);
     res.redirect("/delivery");
  });
});


// user route
// app.get("/create",function(req,res) {
//    res.render("user/home",{status:datastatus});
// });
// app.post("/create",function(req,res) {
//    var name = req.body.name;
//    var email = req.body.email;
//    var address = req.body.address;
//    var contact = req.body.contact;
//    var password = req.body.password;
//
//    // console.log(name);
//    // console.log(email);
//    // console.log(address);
//    // console.log(contact);
//    // console.log(password);
//
//    var checkquery = "SELECT email FROM login";
//    con.query(checkquery,function(err,response) {
//      for(var i = 0;i<= response.length-1;i++){
//         if(response[i].email === email){
//           datastatus = "Sorry we have already acount on this Email..";
//           res.redirect("/create");
//           break;
//         }else{
//            insertData();
//            break;
//         }
//      }
//    });
//    function insertData() {
//      var insertquery = "INSERT INTO login (name , email , address , contact , password ) VALUES (?, ?, ?, ?, ?)";
//      var query = mysql.format(insertquery,[name,email,address,contact,password]);
//
//      con.query(query, function (err, result) {
//       if (err) throw err;
//       console.log("1 record inserted");
//       datastatus = "Sucessfully Insert"
//       res.redirect("/create");
//       });
//    }
//
// });
// app.post("/login",function(req,res){
//    var email = req.body.email;
//    var pass = req.body.password;
//    var searchquery = "SELECT *FROM login WHERE email = ? AND password = ?";
//    con.query(searchquery,[email,pass],function(err,response) {
//      if(err) throw err;
//      if(!response){
//        res.send("Please check your email or password.");
//      }
//      else {
//        if(response[0].email === email && response[0].password === pass){
//          console.log("sucessfully");
//          res.send("sucessfully login..");
//        }
//      }
//    });
// });
app.post("/admindelete",function(req,res) {
  console.log(req.body);
  var delete_content = req.body.admindelete;
  var query = "DELETE FROM adminlogin WHERE admin_id =?";
  con.query(query,[delete_content],function (err, result) {
     if(err) throw err;
     console.log(result);
     // res.send(result);
     res.redirect("/dashboard");
  });
});

app.get("/blogcompose",function(req,res) {
if(req.session.admin!=undefined) {
  var query = "SELECT * FROM blog";
  con.query(query,function(err,response) {
    if(err) throw err;

    res.render("admin/blogadmin.ejs",{postlist:response});
  });
}
else{
  res.redirect("dash-admin");
}
});
app.post("/blogcompose",function(req,res) {
  // console.log(req.body);
  // console.log(req.files.blogpostimg);
  // res.send(req.body);
  var blog_post_title = req.body.title;
  var blog_post_desc = req.body.blogdesc;
  var blog_post_img = req.files.blogpostimg.name;
  var insertquery = "INSERT INTO blog (title , image, desc_post) VALUES (?, ?, ?)";
  var query = mysql.format(insertquery,[blog_post_title,blog_post_img,blog_post_desc]);

  con.query(query, function (err, result) {
   if (err) throw err;
   console.log("1 record inserted");
   // res.redirect("/blogcompose");
   // res.render('admin/blogadmin.ejs');

   });
   // console.log(req.files.blogpostimg);
   // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
   let sampleFile = req.files.blogpostimg;
   // Use the mv() method to place the file somewhere on your server
   var dirpath = "/public/upload/blog/"+blog_post_img;
   sampleFile.mv(path.join(__dirname,dirpath), function(err) {

       if (err)
       return res.status(500).send(err);
       successupload  = "Sucessfully Upload Your Post";
       res.redirect("/blogcompose");
   });
});
app.post('/blogpostdelete',function(req,res) {
  var delete_content = req.body.postdelete;
  var query = "DELETE FROM blog WHERE blog_id =?";
  con.query(query,[delete_content],function (err, result) {
     if(err) throw err;
     // console.log(result);
     // res.send(result);
     res.redirect("/blogcompose");
  });
});
// ############################################ Practice #################################################### Rafey ######################


//***********************************ADMIN PANEL ********************************************************************************************
//===========================================================================================================================================




app.get("/", function(req, res) {

  var query = "SELECT * FROM deal";
  con.query(query,function(err,result) {
    if(err) throw err;
    if(result.length!=0) {
      dis = result[0].discount;
      prName = result[0].dealname;
    }
    else {
      dis = 0;
      prName="";
    }
      // console.log(prName+" "+dis);
  });


  var cat = [];
  con.query("SELECT * FROM category", function (err, result) {
   if (err) throw err;
    cat = result.slice();
   });

  con.query("SELECT * FROM product", function (err, result) {
   if (err) throw err;
   result.forEach(function(e){
     if(_.lowerCase(prName)==_.lowerCase(e.name)) {
      prImg = e.image1;
      prPrice = e.price;
      prId = e.product_id;

    }
   });
   var d = (100-dis)*prPrice/100.0;
   // console.log(prPrice+", "+prId+", "+d);
   res.render("home",{products:result,prId:prId, categories:cat, dealN: prName, dealI:prImg, dealD:d, pPrice:prPrice});
 });
});

app.post("/search", function(req, res){
  var prdSrh = _.lowerCase(req.body.search);
  res.redirect("/search/"+prdSrh);
});

app.get("/search/:pS", function(req, res, next){
  const prdSrh = req.params.pS;
  var sp = [];
  con.query("SELECT * FROM product", function (err, result) {
   if (err) throw err;
   result.forEach(function(element) {

     const prd = _.lowerCase(element.name);

     if(prd == prdSrh) {
      sp.push(element);
     }

   });

    res.render("search", {p:result, srch:sp})
   });
});


app.get("/category", function(req,res){

  con.query("SELECT * FROM category", function (err, result) {
   if (err) throw err;
   res.render("allCategory", {c: result});
   });


  // res.render("allCategory", {c: categories});
});

app.get("/products", function(req,res){

  con.query("SELECT * FROM product", function (err, result) {
   if (err) throw err;
   res.render("allProducts", {p: result});
   });

  //res.render("allProducts", {p: products});
});


app.get("/category/:cat", function(req,res) {
    const reqTitle = _.lowerCase(req.params.cat);
    var products = [];

    con.query("SELECT * FROM product", function (err, result) {
     if (err) throw err;
     products = result;
   });

    con.query("SELECT * FROM category", function (err, result) {
     if (err) throw err;
     result.forEach(function(element) {

       const storedTitle = _.lowerCase(element.name);
           if(reqTitle == storedTitle)
             res.render("category", {name:element.name, i:element.category_id, p:products, desc:element.description});
       });
     });
});

app.get("/products/:prodID", function(req, res) {
  const reqTitle =req.params.prodID;
  //console.log(reqTitle);
  var products = [];
  con.query("SELECT * FROM product", function (err, result) {
    if (err) throw err;
    result.forEach(function(element) {
        const storedTitle = element.product_id;
        if(reqTitle == storedTitle) {
          var img = [element.image1, element.image2, element.image3];
          console.log(img);
          res.render("product", {pimg:img, pName: element.name, pPrice: element.price, pID: element.product_id, pDes: element.description, pS:element.stock});

        }
    });
//res.render("product",{pimg:null, pName: null, pPrice: null, pID: null});
  });
});




//========================================================================
//cart code -----------------------------

app.get('/add-to-cart/:id', function(req, res, next) {
    var productId = req.params.id;
    var cart = new Cart(req.session.cart ? req.session.cart : {});
    var products = [];
    var d = 0;
    if(productId == prId) {
      d = (dis)*prPrice/100.0;
      console.log(d);
    }

    con.query("SELECT * FROM product", function (err, result) {
     if (err) throw err;
  //   products = result;

      result.forEach(function(product) {
        if(product.product_id == productId) {


          if(product.stock <=0){
            alertMsg("Out of stock!");
            res.back();
          }else {



          cart.add(product, product.product_id,d);
          req.session.cart = cart;
	  return res.back();
        //  res.redirect('/products/'+product.product_id);
      }}
      });
    });
});

app.get('/shopping-cart', function(req, res, next) {
   if (!req.session.cart) {
       return res.render('cart', {products: null});
   }
    var cart = new Cart(req.session.cart);
    res.render('cart', {products: cart.generateArray(), totalPrice: cart.totalPrice, totalQty: cart.totalQty});
});

app.get('/reduce/:id', function(req, res, next) {
    var productId = req.params.id;
    var cart = new Cart(req.session.cart ? req.session.cart : {});

    cart.reduceByOne(productId);
    req.session.cart = cart;
    res.redirect('/shopping-cart');
});

app.get('/add/:id', function(req, res, next) {
    var productId = req.params.id;
    var cart = new Cart(req.session.cart ? req.session.cart : {});

    cart.addByOne(productId);
    req.session.cart = cart;
    res.redirect('/shopping-cart');
});

app.get('/remove/:id', function(req, res, next) {
    var productId = req.params.id;
    var cart = new Cart(req.session.cart ? req.session.cart : {});

    cart.removeItem(productId);
    req.session.cart = cart;
    res.redirect('/shopping-cart');
});
//============================================================================

app.get('/about',function(req,res) {
  res.render("about");
});
var m = "";
app.post("/deliverycheck", function(req, res) {
  var p = Number(req.body.del);

  con.query("SELECT * FROM area", function (err, result) {
    var f = false;
    if (err) throw err;
    for(var i = 0;i<=result.length-1;i++) {
      if(result[i].pincode === p) {
        f = true;
        break;
      }
    }

  if(f==true) {
    m = "Hurray! This location is available.";
  } else  {
    m = "Sorry! Cannot deliver to this location";
  }
  res.redirect("deliverycheck");
});
});

app.get("/deliverycheck", function(req, res) {
  res.render("deliverycheck",{m:m});
  m = "";
});

app.get("/checkout", loginController.checkLoggedIn, function(req, res) {

  var userD = {
    name: "",
    contact: "",
    address: "",
    email: "",
    pincode: ""
  };

  var i = req.session.passport.user;
  console.log(i);
  con.query("SELECT * FROM users WHERE id = ?",[i], function(err,res){
    userD.name = res.fullname;
    userD.contact = res.contact;
    userD.address = res.address;
    userD.email = res.email;
    userD.pincode = res.pincode;
  });

  var cartD = [];

  if(req.session.cart!=undefined) {
    var productsInCart = Object.keys(req.session.cart.items);

    productsInCart.forEach(function(prod){

      var productname = req.session.cart.items[prod].item.name;
      var productStock = req.session.cart.items[prod].item.stock;
      var productCartQty = req.session.cart.items[prod].qty;
      var newQty = productStock - productCartQty;

      var cartO = {
        name: productname,
        p: req.session.cart.items[prod].price,
        q: productCartQty
      };
      cartD.push(cartO);

      con.query("UPDATE product SET stock = ? WHERE name = ?",[newQty, productname],function(err){
        if(err) throw err;
      });
      con.query("UPDATE product SET sale = sale+1 WHERE name = ?",[productname],function(err){
        if(err) throw err;
      });
    });
    req.session.cart = {};


    res.render("checkout");
  }
  else {
    res.redirect("/");
  }
});

app.get("/membership", loginController.checkLoggedIn, function(req,res){
  res.render("membership.ejs");
});

app.get("/members", loginController.checkLoggedIn, function(req, res) {
  var i = req.session.passport.user;

  con.query("UPDATE users SET member = 'A' WHERE id = ?",[i], function(err,res){
    if(err) throw err;
  });
  res.redirect("/");

});




app.listen(3000, function() {
  console.log("Server started on port 3000");
});
